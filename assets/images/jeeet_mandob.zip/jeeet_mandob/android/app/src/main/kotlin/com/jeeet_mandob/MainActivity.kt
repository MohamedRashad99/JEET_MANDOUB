package com.jeeet_mandob

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
