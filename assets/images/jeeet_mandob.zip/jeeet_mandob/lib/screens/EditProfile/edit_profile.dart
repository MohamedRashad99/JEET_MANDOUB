import 'package:flutter/material.dart';
import 'package:jeeet_mandob/constants.dart';
import 'package:jeeet_mandob/generated/locale_keys.g.dart';
import 'package:jeeet_mandob/screens/Congratulations/congratualtions.dart';
import 'package:jeeet_mandob/screens/ImagePicker/image_picker.dart';
import 'package:jeeet_mandob/widgets/customButton.dart';
import 'package:jeeet_mandob/widgets/customTextFeild.dart';
import 'package:easy_localization/easy_localization.dart';
import 'dart:io';
import 'package:image_picker/image_picker.dart';
    class EditProfile extends StatefulWidget {
      @override
      _EditProfileState createState() => _EditProfileState();
    }

    class _EditProfileState extends State<EditProfile> {
      File image;
      File image2;
      File idNumberImge;
      File frontCameraImage;
      File backCameraImage;
      File expirationImage;

      final picker = ImagePicker();
      Future<File> imageMedthod()async{
        File returnImage= await TakeImage.imageFile(context);
        if (returnImage!=null){
          return File(returnImage.path);
        }else{
          print("errooooooooooooooor");
        }
      }
      @override
      Widget build(BuildContext context) {
        double height = MediaQuery.of(context).size.height;
        double width = MediaQuery.of(context).size.width;
        return Scaffold(
          backgroundColor: kBackgroundColor,
          appBar: AppBar(backgroundColor: kPrimaryColor,title: Text(LocaleKeys.personalInfos.tr()),),
          body: Container(
            height: height,
            width: width,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(height: height*0.04,),
                  GestureDetector(
                    onTap: ()async{
                      image = await imageMedthod();
                      setState(() {
                      });
                    },
                    child: CircleAvatar(
                      maxRadius: 40,
                      backgroundImage: image == null ? null:FileImage(image),
                      child: Center(child:  image == null ? Icon(Icons.camera_alt_outlined,) : Container(),),

                    ),
                  ),
                  SizedBox(height: height*0.01,),
                  Text(LocaleKeys.editProfile.tr(),style: TextStyle(fontFamily: "dinnextl bold",fontSize: 18)),
                  SizedBox(height: height*0.04,),
                  CustomTextField(onTap: (){},hint: LocaleKeys.ahmedAlmorsehdy.tr(), dIcon: Icons.person_add,),
                  CustomTextField(onTap: (){},hint: LocaleKeys.email.tr(), dIcon: Icons.email,),
                  Container(
                    height: height*0.07,
                    width: width*0.85,
                    decoration: BoxDecoration( color: kHomeColor,borderRadius: BorderRadius.circular(3)),
                    child: Row(
                      children: [
                        Padding(
                          padding:  EdgeInsets.symmetric(horizontal: 15),
                          child: Image.asset("assets/images/flag.png",height: height*0.05,width: width*0.1, ),
                        ),
                        Text("+966",style: TextStyle(fontFamily: "dinnextl bold"),),
                        SizedBox(width: width*0.1,),
                        Text("122148879",style: TextStyle(fontSize: 14,fontFamily: "dinnextl regular",color: kTextColor)),
                        SizedBox(width: width*0.15,),
                        Icon(Icons.edit,color: Colors.grey,),
                      ],),

                  ),
                  CustomTextField(onTap: (){},hint: LocaleKeys.city.tr(),icon:Icons.location_on_outlined, dIcon: Icons.location_on_outlined,),
                  CustomTextField(onTap: (){},hint: LocaleKeys.idNumberE.tr(), dIcon: Icons.perm_identity_outlined,),
                  CustomTextField(onTap: (){},hint: LocaleKeys.plateNumber.tr(), dIcon: Icons.car_repair,),
                  CustomTextField(onTap: (){},hint: LocaleKeys.licencExpirationDate.tr(), dIcon:  Icons.edit,),
                  SizedBox(height: height*0.04,),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      GestureDetector(
                        onTap: ()async{
                          image2 = await imageMedthod();
                          setState(() {
                          });
                        },
                        child: Container(
                            decoration: BoxDecoration(color:kHomeColor,borderRadius:BorderRadius.circular(8) ,),
                            height: height*0.12,
                            width: width*0.35,
                            child: image2==null?Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                SizedBox(height: height*0.03,),
                                Icon(Icons.camera_alt_outlined,color: kTextColor,),
                                Center(child: Text(LocaleKeys.imageForCarLicence.tr(),style: TextStyle(fontFamily: "dinnextl regular",color: kTextColor,fontSize: 12),textAlign: TextAlign.center,)),
                              ],
                            ):ClipRRect(child:Image.file(image2,fit: BoxFit.cover,),borderRadius:BorderRadius.circular(8))
                        ),
                      ),
                      GestureDetector(
                        onTap: ()async{
                          idNumberImge = await imageMedthod();
                          setState(() {
                          });
                        },
                        child: Container(
                            decoration: BoxDecoration(color:kHomeColor,borderRadius:BorderRadius.circular(8) ),
                            height: height*0.12,
                            width: width*0.35,
                            child:idNumberImge==null? Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                SizedBox(height: height*0.03,),
                                Icon(Icons.camera_alt_outlined,color: kTextColor,),
                                Text(LocaleKeys.idNumber.tr(),style: TextStyle(fontFamily: "dinnextl regular",color: kTextColor,fontSize: 12),textAlign: TextAlign.center,),
                              ],
                            ):ClipRRect(child:Image.file(idNumberImge,fit: BoxFit.cover,),borderRadius:BorderRadius.circular(8))
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: height*0.02,),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      GestureDetector(
                        onTap: ()async{
                          frontCameraImage = await imageMedthod();
                          setState(() {
                          });
                        },

                        child: Container(
                            decoration: BoxDecoration(color:kHomeColor,borderRadius:BorderRadius.circular(8) ),
                            height: height*0.12,
                            width: width*0.35,
                            child: frontCameraImage==null?Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                SizedBox(height: height*0.03,),
                                Icon(Icons.camera_alt_outlined,color: kTextColor,),
                                Text(LocaleKeys.imageCarFront.tr(),style: TextStyle(fontFamily: "dinnextl regular",color: kTextColor,fontSize: 12),textAlign: TextAlign.center,),
                              ],
                            ):ClipRRect(child:Image.file(frontCameraImage,fit: BoxFit.cover,),borderRadius:BorderRadius.circular(8))
                        ),
                      ),
                      GestureDetector(
                        onTap: ()async{
                          backCameraImage = await imageMedthod();
                          setState(() {
                          });
                        },
                        child: Container(
                            decoration: BoxDecoration(color:kHomeColor,borderRadius:BorderRadius.circular(8) ),
                            height: height*0.12,
                            width: width*0.35,
                            child:backCameraImage==null? Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                SizedBox(height: height*0.03,),
                                Icon(Icons.camera_alt_outlined,color: kTextColor,),
                                Text(LocaleKeys.imageCarBack.tr(),style: TextStyle(fontFamily: "dinnextl regular",color: kTextColor,fontSize: 12),textAlign: TextAlign.center,),
                              ],
                            ):ClipRRect(child:Image.file(backCameraImage,fit: BoxFit.cover,),borderRadius:BorderRadius.circular(8))
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: height*0.04,),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(LocaleKeys.licencExpirationDate.tr(),style: TextStyle(fontFamily: "dinnextl bold",fontSize: 14),textAlign: TextAlign.center,),
                      SizedBox(width:width*0.1,),
                      GestureDetector(
                        onTap: ()async{
                          expirationImage = await imageMedthod();
                          setState(() {
                          });
                        },
                        child: Container(
                            decoration: BoxDecoration(color: Colors.white, borderRadius:BorderRadius.circular(8) ),
                            height: height*0.06,
                            width: width*0.15,

                            child:Container(
                              child: expirationImage == null ?
                              Icon(Icons.camera_alt_outlined,color: kTextColor,)
                                  :ClipRRect(child: Image.file(expirationImage,fit: BoxFit.fitWidth,),borderRadius: BorderRadius.circular(8),) ,)),
                      ),
                    ],
                  ),
                  SizedBox(height: height*0.04,),

                  CustomButton(onPressed: (){
                   // Navigator.push(context, MaterialPageRoute(builder: (context)=>CongratualtionsView()));
                  }, title: LocaleKeys.save.tr()),
                  SizedBox(height: height*0.04,),







                ],
              ),
            ),
          ),


        );
      }
    }
