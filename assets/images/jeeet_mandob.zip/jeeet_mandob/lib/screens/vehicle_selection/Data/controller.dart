import 'package:jeeet_mandob/network/network.dart';
import 'package:jeeet_mandob/screens/vehicle_selection/Data/model.dart';
class GetCarController{
  NetWork _netWork = NetWork();
  SelectCarModel _selectCarModel = SelectCarModel();


  Future<SelectCarModel> GetCars()async{
    var response = await _netWork.getData(url: 'cars',);
    _selectCarModel = SelectCarModel.fromJson(response);
    print("${response}pppppppppppppppppp");
    return _selectCarModel;
  }
}