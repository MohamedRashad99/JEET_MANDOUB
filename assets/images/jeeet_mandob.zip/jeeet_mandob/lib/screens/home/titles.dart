import 'package:flutter/material.dart';
import 'package:flutter_switch/flutter_switch.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:jeeet_mandob/generated/locale_keys.g.dart';
import 'package:jeeet_mandob/screens/home/Provider/activationKiloMeter.dart';
import 'package:provider/provider.dart';


import '../../constants.dart';

class Titles extends StatefulWidget {
  @override
  _TitlesState createState() => _TitlesState();
}

class _TitlesState extends State<Titles> {
  bool val = false;
  @override
  Widget build(BuildContext context) {
    var activeButtom = Provider.of<ActivationKiloMeter>(context,);

    final height = MediaQuery.of(context).size.height;
    final width = MediaQuery.of(context).size.width;
    return Column(
      children: [
        Column(
         crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              margin: EdgeInsets.symmetric(horizontal: 20,vertical: 10),
              child: Row(
                children: [
                  Text(
                    LocaleKeys.welcome.tr(),
                    style: TextStyle(color: Colors.black,fontFamily: 'dinnextl bold'),
                  ),
                  SizedBox(
                    width: 5,
                  ),
                  Text(
                    LocaleKeys.ahmedAlmorsehdy.tr(),
                    style: TextStyle(
                        color: Colors.red,fontFamily: 'dinnextl bold'),
                  ),
                ],
              ),
            ),
            Container(
              margin: EdgeInsets.symmetric(horizontal: 20),
              child: Text(
                LocaleKeys.anotherDay.tr(),
                style: TextStyle(color: Colors.grey,),
              ),
            ),
          ],
        ),
        Padding(
          padding: const EdgeInsets.only(top: 40, left: 20),
          child: Row(
            children: [
              Text(
                LocaleKeys.activation.tr(),
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 20),
                child: FlutterSwitch(
                  height: height*0.05,
                  width: width*0.2,
                  activeColor: kPrimaryColor,
                  value: val,
                  onToggle: (newValue) {
                    setState(() {
                     val = newValue;
                      if(val == false){
                        activeButtom.activate= 0;
                      }else{
                        activeButtom.activate= 1;
                      }
                     print(activeButtom.activate);
                    });
                  },
                ),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 30),
          child: Text(
            LocaleKeys.choose.tr(),
            style: TextStyle(color: Colors.grey),
          ),
        ),
      ],
    );
  }
}
