import 'package:flutter/material.dart';
import 'package:jeeet_mandob/screens/new_orders/view.dart';
import 'package:jeeet_mandob/screens/orders_record/view.dart';
import 'package:jeeet_mandob/generated/locale_keys.g.dart';
import 'package:easy_localization/easy_localization.dart';

class ChooseService extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    final width = MediaQuery.of(context).size.width;
    return  Padding(
      padding: const EdgeInsets.only(top: 30),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Container(
            padding: EdgeInsets.only(top:10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color:  Colors.white,
            ),
            height: height*0.25,
            width: width*0.4,
            child:FlatButton(
              onPressed: (){
                Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => NewOrders()));

              },
              child: Column(
                children: [
                  Image.asset("assets/images/delivery_logo.png"),
                  Padding(
                    padding: const EdgeInsets.only(top: 40),
                    child: Text(LocaleKeys.newOrders.tr(),style: TextStyle(fontWeight: FontWeight.bold,fontSize: 17),),
                  ),
                ],
              ),
            ),
            //

          ),
          Container(
            padding: EdgeInsets.only(top:10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color:  Colors.white,
            ),
            height: height*0.25,
            width: width*0.4,
            child:FlatButton(
              onPressed: (){
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => OrdersRecord()),
                );
              },
              child: Column(
                children: [
                  Image.asset("assets/images/order_logo.png"),
                  Padding(
                    padding: const EdgeInsets.only(top:18),
                    child: Text(LocaleKeys.orderRecord.tr(),style: TextStyle(fontWeight: FontWeight.bold,fontSize: 17),),
                  ),
                ],
              ),
            ),
            //

          ),
        ],
      ),
    );
  }
}
