import 'package:flutter/material.dart';

class ActivationKiloMeter extends ChangeNotifier {
  var activate;
}