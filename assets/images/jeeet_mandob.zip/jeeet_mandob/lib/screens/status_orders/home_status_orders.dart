import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:jeeet_mandob/constants.dart';
import 'package:jeeet_mandob/generated/locale_keys.g.dart';



class HomeStatusOrders extends StatefulWidget {
  @override
  _HomeStatusOrdersState createState() => _HomeStatusOrdersState();
}

class _HomeStatusOrdersState extends State<HomeStatusOrders> {
  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: kBackgroundColor,
      appBar: AppBar(
        backgroundColor: kPrimaryColor,
        title:Text(
            LocaleKeys.orderStatus.tr(),
            style: TextStyle(
              fontFamily: 'dinnextl bold',
              fontSize: 20,
            ),
          )
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            //locationRec , deliverySite,totalPrice,status,captainName,orderNumber
            SizedBox(height: height*0.02,),

            buildContainer(height: height*0.11 , width: width*0.9,text1: LocaleKeys.city.tr() ,text2:"Jeddah",height2: height*0.007 ,width2: width),
            buildContainer(height: height*0.11 , width: width*0.9,text1: LocaleKeys.carType.tr() ,text2:"Mercedes",height2: height*0.007 ,width2: width),
            buildContainer(height: height*0.11 , width: width*0.9,text1: LocaleKeys.locationRec.tr() ,text2:"Lorem",height2: height*0.007 ,width2: width),
            buildContainer(height: height*0.11 , width: width*0.9,text1: LocaleKeys.deliverySite.tr(),text2:"Lorem",height2: height*0.007 ,width2: width),
            buildContainer(height: height*0.11 , width: width*0.9,text1: LocaleKeys.totalPrice.tr() ,text2:"Lorem",height2: height*0.007 ,width2: width),
            buildContainer(height: height*0.11 , width: width*0.9,text1: LocaleKeys.status.tr() ,text2:"Lorem",height2: height*0.007 ,width2: width),
            buildContainer(height: height*0.11 , width: width*0.9,text1:LocaleKeys.captainName.tr() ,text2:"Lorem",height2: height*0.007 ,width2: width),
            buildContainer(height: height*0.11 , width: width*0.9,text1: LocaleKeys.orderNumber.tr() ,text2:"Lorem",height2: height*0.007 ,width2: width),

            Padding(
              padding:  EdgeInsets.only(top: 40,left: 25,bottom: 40),
              child: Align(child: CircleAvatar(maxRadius: 25,backgroundColor: kPrimaryColor,child: Image.asset("assets/images/messages.png",),),alignment: Alignment.topLeft,),
            ),

          ],
        ),
      ),
    );
  }
  Widget buildContainer({double height, double width ,text1 , text2 ,double height2 ,double width2 }) {
    return Container(
            margin: EdgeInsets.symmetric(vertical: 4),
            //padding: EdgeInsets.symmetric(vertical: 1,),
            decoration: BoxDecoration(color: kHomeColor,borderRadius: BorderRadius.circular(8)),
            height: height,
            width: width,
            child: Column(
             // crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: height*0.1,),
                Padding(
                  padding:  EdgeInsets.symmetric(horizontal: 15),
                  child: Align(alignment:Alignment.centerLeft,child: Text(text1,style: TextStyle(fontFamily: 'dinnextl bold',fontSize: 16,),)),
                ),
                SizedBox(height: height*0.1,),

                Padding(
                  padding:  EdgeInsets.symmetric(horizontal: 15),
                  child: Align(alignment:Alignment.centerRight ,child: Text(text2,style: TextStyle(fontFamily: 'dinnextl regular',fontSize: 14,color: kTextColor),)),
                ),
                SizedBox(height: height*0.12,),
                Container(
                // margin: EdgeInsets.symmetric(vertical: 10),
                 decoration: BoxDecoration( color: kTextColor,borderRadius: BorderRadius.circular(8)),
                 height: height2,
                  width: width2,
               ),
              ],
            ),
          );
  }


}
