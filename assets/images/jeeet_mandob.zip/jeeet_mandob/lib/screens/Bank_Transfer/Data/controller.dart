import 'package:dio/dio.dart';
import 'package:jeeet_mandob/network/network.dart';
import 'package:jeeet_mandob/screens/Bank_Transfer/Data/model.dart';
import 'package:shared_preferences/shared_preferences.dart';
import'dart:io';
class BankController {
  NetWork _netWork = NetWork();
  Future<void> getBankData({int deliveryID,int Amount, File Image,String SenederName}) async {
    SharedPreferences _prefs = await SharedPreferences.getInstance();
    print("تحويل بنكي " + _prefs.getString("token"));
    Map<String, dynamic> _body = {
      "delivery_id": deliveryID,
      "amount": Amount,
      "image":await MultipartFile.fromFile(Image.path,),
      "sender_name": SenederName,
    };
    FormData _formData = FormData.fromMap(_body);
    var response =
    await _netWork.postData(url: 'deliverybank_transfer', formData: _formData,
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
          "Authorization": "Bearer ${_prefs.getString("token")} "
        });
    if (response != null) {
      print(response);
    } else {
      print("error");
    }
    print(response);
    return response;
  }
}
