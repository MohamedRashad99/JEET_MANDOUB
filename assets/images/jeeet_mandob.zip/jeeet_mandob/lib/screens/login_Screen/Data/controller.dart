import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:jeeet_mandob/generated/locale_keys.g.dart';
import 'package:jeeet_mandob/network/network.dart';
import 'package:jeeet_mandob/screens/Congratulations/congratualtions.dart';
import 'package:jeeet_mandob/screens/home/view.dart';
import 'package:jeeet_mandob/screens/personal_info/Data/signUpProfileModel.dart';
import 'package:jeeet_mandob/screens/signup_screen/provider.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:jeeet_mandob/constants.dart';
import '../../../constants.dart';

class SignInController{
  NetWork _netWork = NetWork();

  Future SignIn({context,var num,var pass})async{
    var provider = Provider.of<SignUpProvider>(context,listen: false);

    savePref(String token)async{
      SharedPreferences preferences = await SharedPreferences.getInstance();
      preferences.setString("token", token);
      print(preferences.getString("token"));
    }
    Map<String,dynamic> _body = {
      "phone":"+966${num}",
      "password":"${pass}",
    };
    var formData = FormData.fromMap(_body);
    var response = _netWork.postData(url: 'login',
        formData: formData,);
    // _profileModel = ProfileModel.fromJson(response);
    response.then((value){
      print(value['data']);
      print(value['msg']);
      if(value['msg']=='success'){
        Navigator.push(context, MaterialPageRoute(
            builder: (context) => HomeScreen()));
        savePref("${value['data']['user']['api_token']}");

      provider.prof_image=null;
      provider.backCameraImage=null;
      provider.insurance_image=null;
      provider.license_image=null;
      provider.id_image=null;
      provider.frontCameraImage=null;
      provider.location=null;
      provider.lat=null;
      provider.lng=null;
      }else if(value['data'] == 'check your phone or password'){
        print("erfgegfe${value}");
        Fluttertoast.showToast(
            msg: "${LocaleKeys.incorrectCredentials.tr()}",
            toastLength: Toast.LENGTH_LONG,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: kPrimaryColor,
            textColor: Colors.white,
            fontSize: 16.0
        );
      }
    });

    return response;
  }
}