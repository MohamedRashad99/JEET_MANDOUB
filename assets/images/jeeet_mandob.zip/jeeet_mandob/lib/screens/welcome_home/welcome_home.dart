import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:jeeet_mandob/constants.dart';
import 'package:jeeet_mandob/generated/locale_keys.g.dart';
import 'package:jeeet_mandob/screens/login_Screen/login_screen.dart';
import 'package:jeeet_mandob/widgets/smallButton.dart';
class WelComeHome extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;
    double width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(backgroundColor: kPrimaryColor,),
      backgroundColor: kBackgroundColor,
      body: Column(
        children: [
          SizedBox(height: height*.2,),
          Text(LocaleKeys.welcomeIn.tr(),
            style: TextStyle(
              fontFamily: "dinnextl bold",
              fontSize:26,),),
          SizedBox(height: height*.15,),
          SizedBox(
              height: height*.15,
              child: Image.asset('assets/images/sLogo.png')),

          SizedBox(height: height*.15,),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SmallButton(onPressed: (){
                context.locale = Locale('en', 'US');
                Navigator.push(context, MaterialPageRoute(builder: (_)=>LoginView()));
              }, title: "English",),
              SmallButton(onPressed: (){
                context.locale = Locale('ar', 'EG');
                Navigator.push(context, MaterialPageRoute(builder: (_)=>LoginView()));
              }, title: "العربية",color: kPrimaryColor,),
            ],
          ),
        ],
      ),
    );
  }
}
