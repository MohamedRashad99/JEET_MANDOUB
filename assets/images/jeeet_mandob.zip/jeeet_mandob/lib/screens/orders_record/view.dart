import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:jeeet_mandob/constants.dart';
import 'package:jeeet_mandob/constants.dart';
import 'package:jeeet_mandob/screens/Parcels/view.dart';
import 'package:jeeet_mandob/screens/orders_record/pages/Bounced/Data/BouncedController.dart';
import 'package:jeeet_mandob/screens/orders_record/pages/Bounced/Data/BouncedModel.dart';
import 'package:jeeet_mandob/screens/orders_record/pages/Done/doneController.dart';
import 'package:jeeet_mandob/screens/orders_record/pages/Done/doneModel.dart';
import 'package:jeeet_mandob/screens/orders_record/pages/Payment/paymentController.dart';
import 'package:jeeet_mandob/screens/orders_record/pages/Payment/paymentModel.dart';
import 'package:jeeet_mandob/screens/orders_record/pages/Uderway/Data/underwayRecordOrderController.dart';
import 'package:jeeet_mandob/screens/orders_record/pages/Uderway/Data/underwayRecordOrderModel.dart';
import 'package:jeeet_mandob/screens/orders_record/pages/bounced.dart';
import 'package:jeeet_mandob/screens/orders_record/pages/done.dart';
import 'package:jeeet_mandob/screens/orders_record/pages/payment.dart';
import 'file:///C:/Users/Ra4ad/AndroidStudioProjects/jeeet_mandob/lib/screens/orders_record/pages/Uderway/underway.dart';
import 'package:jeeet_mandob/generated/locale_keys.g.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:jeeet_mandob/screens/status_orders/home_status_orders.dart';

class OrdersRecord extends StatefulWidget {
  @override
  _OrdersRecordState createState() => _OrdersRecordState();
}

class _OrdersRecordState extends State<OrdersRecord>
    with SingleTickerProviderStateMixin {

  //***************   UnderWay Model  & Controller ********************
  UnderWayModel _wayModel =UnderWayModel();
  OrdersController _underwayController =OrdersController();
  DoneController _doneController = DoneController();
  BouncedController _bouncedController = BouncedController();
  PaymentController _paymentController = PaymentController();


  bool loading = true;

  void _getData()async{
    _wayModel = await _underwayController.getOrders();
    _wayModel = await _doneController.getDone();
    _wayModel = await _bouncedController.getBounced();
    _wayModel = await _paymentController.getPayment();
    setState(() {
      loading = false;
    });
  }
  //***************   Done Call Model & Controller ********************
/*  DoneModel _doneModel = DoneModel();
  DoneController _doneController = DoneController();
  bool loadingD = true;
  void _getDone()async{
    _doneModel = await _doneController.getDone();
    setState(() {
      loadingD = false;
    });
  }*/

  //********************* Bounced Call Model & Controller****************************


 /* BouncedModel _bouncedModel = BouncedModel();
  BouncedController _bouncedController = BouncedController();
  bool loadingB = true;
  void _getBounced()async{
    _bouncedModel = await _bouncedController.getBounced();
    setState(() {
      loadingB = false;
    });
  }*/

  //********************* Payment Call Model & Controller****************************
/*  PaymentModel _paymentModel =PaymentModel();
  PaymentController _paymentController = PaymentController();
  bool loadingP = true;
  void _getPayment()async{
   _paymentModel = await _paymentController.getPayment();
    setState(() {
      loadingP = false;
    });
  }*/



  TabController _tabController;
  @override
  void initState() {
    _getData();
    /*_getDone();
    _getBounced();
    _getPayment();*/
    _tabController = TabController(length: 4, vsync: this, initialIndex: 0);
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;

    return DefaultTabController(
      length: 4,
      child: Scaffold(
        backgroundColor: kBackgroundColor,
        appBar: AppBar(
          backgroundColor: kPrimaryColor,
          title: Text(
            LocaleKeys.orderRecord.tr(),
            style: TextStyle(fontSize: 20, fontFamily: 'dinnextl bold'),
          ),
        ),
        body: Column(
          children: [
            Container(
              decoration: BoxDecoration(borderRadius:BorderRadius.circular(8),color: kHomeColor ),

              margin: EdgeInsets.symmetric(vertical: 15),
              height: height*0.07,
              width: width*0.9,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                Text(LocaleKeys.search.tr(),style: TextStyle(color: kTextColor,fontFamily: 'dinnextl medium'),),
                SizedBox(width: width*0.2,),
                Icon(Icons.search_sharp,color: Colors.grey,)
              ],),

            ),
            Container(
              height: height * 0.14,
              margin: EdgeInsets.only(top: 28),
              child: TabBar(
                controller: _tabController,
                indicatorColor: kPrimaryColor,
                indicatorSize: TabBarIndicatorSize.tab,
                indicatorWeight: 3,
                unselectedLabelColor: Colors.black,
                labelColor: kPrimaryColor,
                isScrollable: true,
                tabs: [
               //  _Tap( height: height, width: width,title: LocaleKeys.underWay.tr(),img:'assets/images/partenership2.png'),
                  Column(

                    children: [
                      SizedBox(
                          child: Image.asset('assets/images/partenership2.png',),
                          height: height * 0.065,
                          width: width * 0.25),
                      SizedBox(height: height*0.025,),
                      Text(
                        LocaleKeys.underWay.tr(),
                        style: TextStyle(
                            fontSize: 14,
                            // color: Colors.black,
                            fontFamily: 'dinnextl medium'),
                      ),
                    ],
                  ),
                  Column(
                    children: [
                      SizedBox(
                          child: Image.asset('assets/images/partnership.png'),
                          height: height * 0.065,
                          width: width * 0.25),
                      SizedBox(height: height*0.025,),

                      Text(
                        LocaleKeys.done.tr(),
                        style: TextStyle(
                            fontSize: 14,
                            //color: Colors.black,
                            fontFamily: 'dinnextl medium'),
                      ),
                    ],
                  ),
                  Column(
                    children: [
                      SizedBox(
                          child: Image.asset('assets/images/partner_icon.png'),
                          height: height * 0.062,
                          width: width * 0.25),
                      SizedBox(height: height*0.01,),

                      Text(
                        'The Bounced\nand its reason',
                        style: TextStyle(
                            fontSize: 12.5,
                            // color: Colors.black,
                            fontFamily: 'dinnextl medium'),
                      ),
                    ],
                  ),
                  Column(
                    children: [
                      SizedBox(
                          child: Image.asset(
                              'assets/images/partnership-icons.png'),
                          height: height * 0.060,
                          width: width * 0.18),
                      SizedBox(height: height*0.01,),

                      Text(
                        'Payment requests\n\t\t\tupon receipt',
                        style: TextStyle(
                            fontSize: 12.5,
                            //color: Colors.black,
                            fontFamily: 'dinnextl medium'),
                      ),
                      SizedBox(
                        width: width * 0.1,
                      )
                    ],
                  ),
                ],
              ),
            ),
            Expanded(
              child: TabBarView(
                  controller: _tabController,
                  children: [
               //***************************  Underway(),  **********************************************,
                loading ? SpinKitChasingDots(
                  size: 20,
                  color: kPrimaryColor,
                ):
                Padding(
                  padding:  EdgeInsets.symmetric(vertical:10),
                  child: ListView.builder(
                    itemCount: _wayModel.data.length,
                    itemBuilder: (_,index)=> GestureDetector(
                      onTap: (){
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) =>ParclesPackages()),
                        );
                      },
                      child: Container(
                        height: height*.26,
                        margin: EdgeInsets.symmetric(horizontal: 20,vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Padding(
                              padding:  EdgeInsets.symmetric(horizontal: 10),
                              child: Align(alignment: Alignment.centerLeft,
                                  child: Text(LocaleKeys.dateOf.tr(),style: TextStyle(fontFamily: 'dinnextl medium',fontSize: 15),textAlign: TextAlign.start,)),
                            ),
                            Padding(
                              padding:  EdgeInsets.symmetric(horizontal: 10),
                              child: Align(alignment: Alignment.centerLeft,
                                  child: Text(_wayModel.data[index].acceptedDate.toString(),style: TextStyle(fontFamily: 'dinnextl medium',fontSize: 13,color: kTextColor),textAlign: TextAlign.start,)),
                            ),
                            Divider(height: 2,),
                            Padding(
                              padding:  EdgeInsets.symmetric(horizontal: 10),
                              child: Align(alignment: Alignment.centerLeft,
                                  child: Text(LocaleKeys.orderNumber.tr(),style: TextStyle(fontFamily: 'dinnextl medium',fontSize: 15),textAlign: TextAlign.start,)),
                            ),
                            Padding(
                              padding:  EdgeInsets.symmetric(horizontal: 10),
                              child: Align(alignment: Alignment.centerLeft,
                                  child: Text(_wayModel.data[index].code.toString(),style: TextStyle(fontFamily: 'dinnextl medium',fontSize: 13,color: kTextColor),textAlign: TextAlign.start,)),
                            ),
                            Divider(height: 2,),
                            Padding(
                              padding:  EdgeInsets.symmetric(horizontal: 10),
                              child: Align(alignment: Alignment.centerLeft,
                                  child: Text(LocaleKeys.captainName.tr(),style: TextStyle(fontFamily: 'dinnextl medium',fontSize: 15),textAlign: TextAlign.start,)),
                            ),
                            Padding(
                              padding:  EdgeInsets.symmetric(horizontal: 10),
                              child: Align(alignment: Alignment.centerLeft,
                                  child: Text(_wayModel.data[index].dealerName.toString(),style: TextStyle(fontFamily: 'dinnextl medium',fontSize: 13,color: kTextColor),textAlign: TextAlign.start,)),
                            ),

                          ],

                        ),
                      ),
                    ),
                  ),
                ),
                //***************************  Done(),  **********************************************,
                loading ? SpinKitChasingDots(
                  size: 20,
                  color: kPrimaryColor,
                ):
                Padding(
                  padding:  EdgeInsets.symmetric(vertical:10),
                  child: ListView.builder(
                    itemCount: _wayModel.data.length,
                    itemBuilder: (_,index)=> GestureDetector(
                      onTap: (){
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => ParclesPackages()),
                        );
                      },
                      child: Container(
                        height: height*.26,
                        margin: EdgeInsets.symmetric(horizontal: 20,vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Padding(
                              padding:  EdgeInsets.symmetric(horizontal: 10),
                              child: Align(alignment: Alignment.centerLeft,
                                  child: Text(LocaleKeys.dateOf.tr(),style: TextStyle(fontFamily: 'dinnextl medium',fontSize: 15),textAlign: TextAlign.start,)),
                            ),
                            Padding(
                              padding:  EdgeInsets.symmetric(horizontal: 10),
                              child: Align(alignment: Alignment.centerLeft,
                                  child: Text(_wayModel.data[index].acceptedDate.toString(),style: TextStyle(fontFamily: 'dinnextl medium',fontSize: 13,color: kTextColor),textAlign: TextAlign.start,)),
                            ),
                            Divider(height: 2,),
                            Padding(
                              padding:  EdgeInsets.symmetric(horizontal: 10),
                              child: Align(alignment: Alignment.centerLeft,
                                  child: Text(LocaleKeys.orderNumber.tr(),style: TextStyle(fontFamily: 'dinnextl medium',fontSize: 15),textAlign: TextAlign.start,)),
                            ),
                            Padding(
                              padding:  EdgeInsets.symmetric(horizontal: 10),
                              child: Align(alignment: Alignment.centerLeft,
                                  child: Text(_wayModel.data[index].code.toString(),style: TextStyle(fontFamily: 'dinnextl medium',fontSize: 13,color: kTextColor),textAlign: TextAlign.start,)),
                            ),
                            Divider(height: 2,),
                            Padding(
                              padding:  EdgeInsets.symmetric(horizontal: 10),
                              child: Align(alignment: Alignment.centerLeft,
                                  child: Text(LocaleKeys.captainName.tr(),style: TextStyle(fontFamily: 'dinnextl medium',fontSize: 15),textAlign: TextAlign.start,)),
                            ),
                            Padding(
                              padding:  EdgeInsets.symmetric(horizontal: 10),
                              child: Align(alignment: Alignment.centerLeft,
                                  child: Text(_wayModel.data[index].dealerName.toString(),style: TextStyle(fontFamily: 'dinnextl medium',fontSize: 13,color: kTextColor),textAlign: TextAlign.start,)),
                            ),

                          ],

                        ),
                      ),
                    ),
                  ),
                ),
               /* Done( ),*/
                //********************************  Bounced(),  ******************************************,
                loading ? SpinKitChasingDots(
                  size: 20,
                  color: kPrimaryColor,
                ):
                Padding(
                  padding:  EdgeInsets.symmetric(vertical:10),
                  child: ListView.builder(
                    itemCount: _wayModel.data.length,
                    itemBuilder: (_,index)=> GestureDetector(
                      onTap: (){
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => ParclesPackages()),
                        );
                      },
                      child: Container(
                        height: height*.26,
                        margin: EdgeInsets.symmetric(horizontal: 20,vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Padding(
                              padding:  EdgeInsets.symmetric(horizontal: 10),
                              child: Align(alignment: Alignment.centerLeft,
                                  child: Text(LocaleKeys.dateOf.tr(),style: TextStyle(fontFamily: 'dinnextl medium',fontSize: 15),textAlign: TextAlign.start,)),
                            ),
                            Padding(
                              padding:  EdgeInsets.symmetric(horizontal: 10),
                              child: Align(alignment: Alignment.centerLeft,
                                  child: Text(_wayModel.data[index].acceptedDate.toString(),style: TextStyle(fontFamily: 'dinnextl medium',fontSize: 13,color: kTextColor),textAlign: TextAlign.start,)),
                            ),
                            Divider(height: 2,),
                            Padding(
                              padding:  EdgeInsets.symmetric(horizontal: 10),
                              child: Align(alignment: Alignment.centerLeft,
                                  child: Text(LocaleKeys.orderNumber.tr(),style: TextStyle(fontFamily: 'dinnextl medium',fontSize: 15),textAlign: TextAlign.start,)),
                            ),
                            Padding(
                              padding:  EdgeInsets.symmetric(horizontal: 10),
                              child: Align(alignment: Alignment.centerLeft,
                                  child: Text(_wayModel.data[index].code.toString(),style: TextStyle(fontFamily: 'dinnextl medium',fontSize: 13,color: kTextColor),textAlign: TextAlign.start,)),
                            ),
                            Divider(height: 2,),
                            Padding(
                              padding:  EdgeInsets.symmetric(horizontal: 10),
                              child: Align(alignment: Alignment.centerLeft,
                                  child: Text(LocaleKeys.captainName.tr(),style: TextStyle(fontFamily: 'dinnextl medium',fontSize: 15),textAlign: TextAlign.start,)),
                            ),
                            Padding(
                              padding:  EdgeInsets.symmetric(horizontal: 10),
                              child: Align(alignment: Alignment.centerLeft,
                                  child: Text(_wayModel.data[index].dealerName.toString(),style: TextStyle(fontFamily: 'dinnextl medium',fontSize: 13,color: kTextColor),textAlign: TextAlign.start,)),
                            ),

                          ],

                        ),
                      ),
                    ),
                  ),
                ),

                //********************************  Payment(),  ******************************************,
                loading ? SpinKitChasingDots(
                  size: 20,
                  color: kPrimaryColor,
                ):
                Padding(
                  padding:  EdgeInsets.symmetric(vertical:10),
                  child: ListView.builder(
                    itemCount: _wayModel.data.length,
                    itemBuilder: (_,index)=> GestureDetector(
                      onTap: (){
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => ParclesPackages()),
                        );
                      },
                      child: Container(
                        height: height*.26,
                        margin: EdgeInsets.symmetric(horizontal: 20,vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Padding(
                              padding:  EdgeInsets.symmetric(horizontal: 10),
                              child: Align(alignment: Alignment.centerLeft,
                                  child: Text(LocaleKeys.dateOf.tr(),style: TextStyle(fontFamily: 'dinnextl medium',fontSize: 15),textAlign: TextAlign.start,)),
                            ),
                            Padding(
                              padding:  EdgeInsets.symmetric(horizontal: 10),
                              child: Align(alignment: Alignment.centerLeft,
                                  child: Text(_wayModel.data[index].acceptedDate.toString(),style: TextStyle(fontFamily: 'dinnextl medium',fontSize: 13,color: kTextColor),textAlign: TextAlign.start,)),
                            ),
                            Divider(height: 2,),
                            Padding(
                              padding:  EdgeInsets.symmetric(horizontal: 10),
                              child: Align(alignment: Alignment.centerLeft,
                                  child: Text(LocaleKeys.orderNumber.tr(),style: TextStyle(fontFamily: 'dinnextl medium',fontSize: 15),textAlign: TextAlign.start,)),
                            ),
                            Padding(
                              padding:  EdgeInsets.symmetric(horizontal: 10),
                              child: Align(alignment: Alignment.centerLeft,
                                  child: Text(_wayModel.data[index].code.toString(),style: TextStyle(fontFamily: 'dinnextl medium',fontSize: 13,color: kTextColor),textAlign: TextAlign.start,)),
                            ),
                            Divider(height: 2,),
                            Padding(
                              padding:  EdgeInsets.symmetric(horizontal: 10),
                              child: Align(alignment: Alignment.centerLeft,
                                  child: Text(LocaleKeys.captainName.tr(),style: TextStyle(fontFamily: 'dinnextl medium',fontSize: 15),textAlign: TextAlign.start,)),
                            ),
                            Padding(
                              padding:  EdgeInsets.symmetric(horizontal: 10),
                              child: Align(alignment: Alignment.centerLeft,
                                  child: Text(_wayModel.data[index].dealerName.toString(),style: TextStyle(fontFamily: 'dinnextl medium',fontSize: 13,color: kTextColor),textAlign: TextAlign.start,)),
                            ),

                          ],

                        ),
                      ),
                    ),
                  ),
                ),

                // Done(),
               // Bounced(),
               // Payment(),
              ]),
            )
          ],
        ),
      ),
    );
  }
}

class _Tap extends StatelessWidget {
  final String  img;
  final String title;
  final double width;
  final double height;
  const _Tap({Key key, this.img, this.title, this.width, this.height}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return  Column(

      children: [
        SizedBox(
            child: Image.asset(
              '$img',
            ),
            height: height * 0.065,
            width: width * 0.25),
        SizedBox(height: height*0.025,),
        Text(
         "$title",
          style: TextStyle(
              fontSize: 14,
              // color: Colors.black,
              fontFamily: 'dinnextl medium'),
        ),
      ],
    );
  }
}
