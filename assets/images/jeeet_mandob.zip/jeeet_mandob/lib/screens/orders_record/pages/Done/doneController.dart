import 'package:jeeet_mandob/network/network.dart';
import 'package:jeeet_mandob/screens/orders_record/pages/Done/doneModel.dart';
import 'package:jeeet_mandob/screens/orders_record/pages/Uderway/Data/underwayRecordOrderModel.dart';
import 'package:shared_preferences/shared_preferences.dart';

class DoneController{
  NetWork _netWork = NetWork();
 // DoneModel _doneModel =DoneModel();
  UnderWayModel _wayModel =UnderWayModel();

  Future<UnderWayModel> getDone() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    print("تم ياكبير" + preferences.getString("token"),);
    var data = await _netWork.getData(url: 'deliveryordersunderwayrecording',
        headers: {
          'Accept':'application/json',
         // 'Authorization':'Bearer 2hDjxsFFtoQ93eG6Jc0hcWnfuyMYhWyBnWTn7tZ2IRuxJ7bUGBSlDkOzwR2nroMtcecaIPcPCQBnw88MeTY3LWC6cnkW6Id4cJBe'
          'Authorization':'Bearer ${preferences.getString("token")}',

        });
   // print(data);
    if (data == null || data == "internet") {
      _wayModel = null;
      return  _wayModel;
    } else {
      _wayModel = UnderWayModel.fromJson(data);
      print(data);
      return  _wayModel;
    }

  }


}