import 'package:jeeet_mandob/network/network.dart';
import 'package:jeeet_mandob/screens/orders_record/pages/Bounced/Data/BouncedModel.dart';
import 'package:jeeet_mandob/screens/orders_record/pages/Uderway/Data/underwayRecordOrderModel.dart';
import 'package:shared_preferences/shared_preferences.dart';

class BouncedController{

  NetWork _netWork = NetWork();
 // BouncedModel _bouncedModel = BouncedModel();
  UnderWayModel _wayModel =UnderWayModel();


  Future<UnderWayModel> getBounced() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    print("قيمةالمحفظ " + preferences.getString("token"),);
    var data = await _netWork.getData(url: 'deliveryordersbouncedrecording',
        headers: {
          'Accept':'application/json',
         // 'Authorization':'Bearer 2hDjxsFFtoQ93eG6Jc0hcWnfuyMYhWyBnWTn7tZ2IRuxJ7bUGBSlDkOzwR2nroMtcecaIPcPCQBnw88MeTY3LWC6cnkW6Id4cJBe'
          'Authorization':'Bearer ${preferences.getString("token")}',

        });
   // print(data);
    if (data == null || data == "internet") {
      _wayModel = null;
      return  _wayModel;
    } else {
      _wayModel = UnderWayModel.fromJson(data);
      print(data);
      return  _wayModel;
    }

  }
}