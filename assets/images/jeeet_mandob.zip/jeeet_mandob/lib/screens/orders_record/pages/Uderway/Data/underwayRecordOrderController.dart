import 'package:jeeet_mandob/network/network.dart';
import 'package:jeeet_mandob/screens/orders_record/pages/Uderway/Data/underwayRecordOrderModel.dart';


class OrdersController {
  UnderWayModel _underWayModel = UnderWayModel();
  NetWork _netWork = NetWork();
  Future<UnderWayModel> getOrders() async {

    var data = await _netWork.getData(url: 'deliveryordersunderwayrecording',
        headers: {
          'Accept':'application/json',
          'Authorization':'Bearer 2hDjxsFFtoQ93eG6Jc0hcWnfuyMYhWyBnWTn7tZ2IRuxJ7bUGBSlDkOzwR2nroMtcecaIPcPCQBnw88MeTY3LWC6cnkW6Id4cJBe'

        });
    print(data);
    if (data == null || data == "internet") {
      _underWayModel = null;
      return  _underWayModel;
    } else {
      _underWayModel = UnderWayModel.fromJson(data);
      return  _underWayModel;
    }
  }
}