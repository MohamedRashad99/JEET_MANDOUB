import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:jeeet_mandob/screens/home/Provider/activationKiloMeter.dart';
import 'package:jeeet_mandob/screens/home/titles.dart';
import 'package:jeeet_mandob/screens/signup_screen/provider.dart';
import 'package:jeeet_mandob/screens/splash/splash.dart';
import 'package:provider/provider.dart';

import 'screens/home/view.dart';


void main() {
  WidgetsFlutterBinding.ensureInitialized();
  Provider.debugCheckInvalidValueType= null;
  runApp(
    MultiProvider(
      //ActivationKiloMeter
      providers: [
        Provider<SignUpProvider>(
            create: (_) => SignUpProvider()),
              Provider<ActivationKiloMeter>(
            create: (_) => ActivationKiloMeter()),

       // ChangeNotifierProvider.value(value: ActivationKiloMeter()),
      ],
      child: EasyLocalization(
        child: MyApp(),
        saveLocale: true,
        supportedLocales: [
          Locale('en', 'US'),
          Locale('ar', 'EG'),
        ],
        path: 'lib/Resources/Translations',
      ),
    ),
  );
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
  ]);
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        localizationsDelegates: context.localizationDelegates,
        supportedLocales: context.supportedLocales,
        locale: context.locale,
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          canvasColor: Colors.transparent,
          primarySwatch: Colors.deepOrange,
          visualDensity: VisualDensity.adaptivePlatformDensity,
        ),
         home: SplashScreen(),
    );
  }
}
